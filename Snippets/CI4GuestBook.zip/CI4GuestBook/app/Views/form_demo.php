<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1> Say Hello</h1>
<form method="post" action="<?= base_url('/hello/submit') ?>" >
    <input type="text" name="name" placeholder="Your name">
    <button type="submit">Send</button>
</form>

</body>
</html>
