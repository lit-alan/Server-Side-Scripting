<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1><?= esc($title) ?></h1>
<p><?= esc($message) ?></p>
</body>
</html>

