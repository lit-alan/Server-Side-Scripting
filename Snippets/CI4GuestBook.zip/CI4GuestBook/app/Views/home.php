<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TUS Holiday Villas</title>

    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>

<body>

<div class="container">

    <h1>Welcome to TUS Holiday Villas</h1>

    <p>
        Enjoy a relaxing stay at our beautiful holiday villas located along Ireland's
        stunning coastline. Our villas offer comfort, luxury, and amazing scenery.
    </p>

    <img src="<?= base_url('/images/villa.png') ?>" alt="Holiday Villa">

    <p>
        Have you stayed with us before? Tell us about your experience!
    </p>

    <a class="guestbook-link" href="<?= site_url('/guestbook/guestbookLink') ?>">
        Sign Our Guest Book
    </a>

</div>

</body>
</html>