<html>

<!-- Display the page title passed from the controller -->
<h1><?= esc($title) ?></h1>

<!-- Form for adding a new guestbook entry -->
<!-- When submitted, it sends a POST request to /guestbook/submit -->
<form method="post" action="<?= base_url('/guestbook/submit')?>" >

    <p>
        <label>Name</label><br>
        <!-- Text field where the user enters their name -->
        <input type="text" name="name">
    </p>

    <p>
        <label>Message</label><br>
        <!-- Text area where the user writes their guestbook message -->
        <textarea name="entry"></textarea>
    </p>

    <!-- Submit button sends the form data to the server -->
    <button type="submit">Add Entry</button>

</form>

<!-- Link to clear all guestbook entries -->
<p>
    <a href="<?= base_url('/guestbook/clear')?>">Clear Guestbook</a>
    <a href="<?= base_url('/guestbook')?>">Home Page</a>
</p>

<hr>

<h2>Entries</h2>

<!-- Check if there are any guestbook entries -->
<?php if (! empty($entries)): ?>

    <!-- Loop through each entry and display it -->
    <?php foreach ($entries as $item): ?>

        <p>
            <!-- Display the name, message, and time -->
            <!-- esc() makes sure the output is safe to display in HTML -->
            <strong><?= esc($item['name']) ?></strong><br>
            <?= esc($item['entry']) ?><br>
            <small><?= esc($item['time']) ?></small>
        </p>

    <?php endforeach; ?>

<?php else: ?>

    <!-- Message shown when there are no entries -->
    <p>No entries yet.</p>

<?php endif; ?>

</html>