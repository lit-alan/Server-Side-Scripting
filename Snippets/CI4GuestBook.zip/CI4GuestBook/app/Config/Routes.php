<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('hello', 'Hello::index');
$routes->get('hello/greet/(:segment)', 'Hello::greet/$1');
$routes->get('hello/form', 'Hello::form');
$routes->post('hello/submit', 'Hello::submit');
$routes->get('guestbook', 'Guestbook::index');
$routes->post('guestbook/submit', 'Guestbook::submit');
$routes->get('guestbook/clear', 'Guestbook::clear');
$routes->get('guestbook/guestbookLink', 'Guestbook::guestbookLink');