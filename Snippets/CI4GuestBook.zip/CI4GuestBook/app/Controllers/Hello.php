<?php
namespace App\Controllers;

class Hello extends BaseController{
    public function index(){
        $data= ['title' => 'Hello Demo',
                'message' => 'this data was passed from the controller'
        ];
        return view('hello_view',$data);
    }

    public function greet($name = "Guest"){
        $data= ['title' => 'Greetings',
            'message' => 'Hello' . $name . "!"
        ];
        return view('hello_view',$data);
    }
    public function form()
    {
          return view('form_demo');
    }

    public function submit()
    {
        $name = $this->request->getPost('name');
        $data= ['title' => 'Greetings',
            'message' => 'Hello' . $name . "!"
        ];
        return view('hello_view',$data);
    }

}