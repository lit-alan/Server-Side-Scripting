<?php

namespace App\Controllers;

/*
| Guestbook Controller
|
| This controller handles the guestbook page. It displays the list of
| entries, accepts new messages from the form, and can clear all entries.
|
| Guestbook entries are stored in the session rather than a database.
|
| A session is temporary data stored on the server that helps a web application remember a user
| during their visit. Since HTTP requests are normally independent, sessions are commonly used to
| store temporary user data such as login information, shopping carts,
| or in this case guestbook entries.
*/

class Guestbook extends BaseController
{

    //Show the guestbook page
    public function index()
    {
        return view('home');
    }
    public function guestbookLink()
    {
        //Get the current session
        $session = session();

        //Prepare data to send to the view
        $data = [
            //Page title
            'title' => 'Mini Guestbook',

            //Get existing guestbook entries from the session
            //If there are no entries yet, use an empty array instead
            'entries' => $session->get('entries') ?? []
        ];

        //Load the guestbook view and pass the data to it
        return view('guestbook', $data);
    }

    //Handle the form submission
    public function submit()
    {
        //Get the current session
        $session = session();

        //Read the name and message entered in the form
        $name  = $this->request->getPost('name');
        $entry = $this->request->getPost('entry');

        //Get the current list of entries from the session
        //If none exist yet, start with an empty array
        $entries = $session->get('entries') ?? [];

        //Only add a new entry if both fields have a value
        if ($name && $entry) {
            //Add a new guestbook entry to the array
            $entries[] = [
                'name' => $name,
                'entry' => $entry,
                'time' => date('H:i:s') //Store the current time
            ];
        }

        //Save the updated entries array back into the session
        $session->set('entries', $entries);

        //Redirect the user back to the guestbook page
        return redirect()->to('/guestbook/guestbookLink');
    }

    //Clear all guestbook entries
    public function clear()
    {
        //Remove the 'entries' item from the session
        session()->remove('entries');

        //Redirect back to the guestbook page
        return redirect()->to('/guestbook/guestbookLink');
    }
}